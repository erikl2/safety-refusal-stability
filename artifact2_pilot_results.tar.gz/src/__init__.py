"""Safety Refusal Stability - Research package for measuring LLM safety behavior consistency."""

__version__ = "0.1.0"
