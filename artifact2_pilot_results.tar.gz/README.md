# Safety Refusal Stability in LLMs

A research project investigating the stability of safety refusal behavior in large language models across random seeds and temperature settings.

## Research Question

**How stable is safety refusal behavior across random seeds and temperature settings?**

When LLMs refuse harmful requests, is this behavior consistent, or does it vary significantly with minor changes to sampling parameters? This project systematically measures refusal stability across multiple models, temperatures, and random seeds.

## Key Metrics

- **Stability Index (SSI)**: Measures consistency of refusal decisions (1.0 = perfectly stable, 0.0 = random)
- **Flip Rate**: Percentage of prompts where the model's decision changes across configurations
- **Refusal Rate**: Percentage of responses classified as refusals

## Models Tested

- Llama 3.1 8B Instruct
- Mistral 7B Instruct v0.3
- Qwen 2.5 7B Instruct

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/safety-refusal-stability.git
cd safety-refusal-stability

# Create virtual environment
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows

# Install dependencies
pip install -r requirements.txt

# Login to HuggingFace (for gated models)
huggingface-cli login
```

### Running the Pipeline

```bash
# 1. Download datasets
python scripts/01_download_data.py

# 2. Preprocess and unify prompts
python scripts/02_preprocess.py

# 3. Run pilot experiment (50 prompts, quick test)
python scripts/03_run_pilot.py

# 4. Run full experiments (GPU required)
python scripts/04_run_experiments.py --model llama-3.1-8b-instruct

# 5. Run judge to classify responses
python scripts/05_run_judge.py

# 6. Compute stability metrics
python scripts/06_compute_metrics.py

# 7. Generate figures
python scripts/07_generate_figures.py
```

## Project Structure

```
safety-refusal-stability/
├── data/
│   ├── raw/              # Original datasets
│   ├── processed/        # Unified prompt dataset
│   └── results/          # Generations, labels, metrics
├── src/
│   ├── data/             # Data loading and preprocessing
│   ├── generation/       # vLLM inference runner
│   ├── evaluation/       # Judge implementation
│   ├── analysis/         # Metrics computation
│   └── visualization/    # Figure generation
├── scripts/              # Pipeline scripts
├── notebooks/            # Analysis notebooks
├── paper/                # LaTeX source and figures
└── configs/              # Configuration files
```

## Datasets

- **AdvBench**: Harmful behaviors dataset from Zou et al. (2023)
- **HarmBench**: Standardized evaluation framework for red teaming

## Configuration

Edit `configs/sampling.yaml` to modify:
- Temperature values
- Random seeds
- Generation parameters

Edit `configs/models.yaml` to add or modify models.

## License

MIT License

## Citation

If you use this code or findings in your research, please cite:

```bibtex
@misc{safety-refusal-stability,
  title={Safety Refusal Stability in Large Language Models},
  author={Your Name},
  year={2024},
  howpublished={\url{https://github.com/yourusername/safety-refusal-stability}}
}
```
